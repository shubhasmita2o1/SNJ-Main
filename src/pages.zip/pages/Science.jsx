
import React from "react";
import { useTranslation } from "react-i18next";
import Container from "../components/Container";
import Reveal from "../components/Reveal";
import PageHeader from "../components/PageHeader";

const GUIDELINES = [
  { code: "NCCN", name: "National Comprehensive Cancer Network" },
  { code: "ASCO", name: "American Society of Clinical Oncology" },
  { code: "ESMO", name: "European Society for Medical Oncology" },
  { code: "SIO", name: "Society for Integrative Oncology" },
];

const TOOLS = [
  { code: "FACT-G", name: "Functional Assessment of Cancer Therapy — General" },
  { code: "HADS", name: "Hospital Anxiety and Depression Scale" },
  { code: "FACIT", name: "Functional Assessment of Chronic Illness Therapy" },
  { code: "PSQI", name: "Pittsburgh Sleep Quality Index" },
];

export default function Science() {
  const { t } = useTranslation();

  return (
    <div data-testid="page-science">
      <PageHeader
        eyebrow={t("science.eyebrow")}
        title={t("science.title")}
        italic={t("science.italic")}
        subtitle={t("science.subtitle")}
        testId="science-header"
      />

      <section className="py-16" data-testid="science-guidelines">
        <Container>
          <Reveal>
            <div className="text-[12px] uppercase tracking-[0.22em] text-[#6F6F6F]">{t("science.alignedWith")}</div>
          </Reveal>
          <Reveal delay={1}>
            <h2 className="mt-6 font-serif text-[40px] md:text-[60px] leading-[1.02] tracking-[-0.02em] max-w-[900px]">
              {t("science.frameworksTitle")} <i className="text-[#6F6F6F]">{t("science.frameworksItalic")}</i>
            </h2>
          </Reveal>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
            {GUIDELINES.map((g, i) => (
              <Reveal key={g.code} delay={i + 1} className="snj-card p-8 flex items-start gap-6">
                <div className="font-serif text-[44px] leading-none w-28 shrink-0">{g.code}</div>
                <div>
                  <div className="text-[18px]">{g.name}</div>
                  <p className="mt-2 text-[#6F6F6F] text-sm leading-relaxed">
                    {t("science.designReferences", { code: g.code })}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
        </Container>
      </section>

      <section className="py-24" data-testid="science-outcomes">
        <Container>
          <Reveal>
            <div className="text-[12px] uppercase tracking-[0.22em] text-[#6F6F6F]">{t("science.instruments")}</div>
          </Reveal>
          <Reveal delay={1}>
            <h3 className="mt-6 font-serif text-[36px] md:text-[52px] leading-[1.02] tracking-[-0.02em]">
              {t("science.measureTitle")} <i className="text-[#6F6F6F]">{t("science.measureItalic")}</i>
            </h3>
          </Reveal>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {TOOLS.map((tool, i) => (
              <Reveal key={tool.code} delay={i + 1} className="snj-card p-7">
                <div className="font-serif text-[34px] leading-none">{tool.code}</div>
                <p className="mt-4 text-[13px] text-[#6F6F6F] leading-relaxed">{tool.name}</p>
              </Reveal>
            ))}
          </div>
        </Container>
      </section>

      <section className="py-20" data-testid="science-research-note">
        <Container size="narrow">
          <Reveal>
            <p className="font-serif text-[32px] md:text-[44px] leading-[1.1] tracking-[-0.015em]">
              {t("science.researchNote")}{" "}
              <i className="text-[#6F6F6F]">{t("science.researchNoteLinkText")}</i>{" "}
              {t("science.researchNoteEnd")}
            </p>
          </Reveal>
        </Container>
      </section>
    </div>
  );
}
