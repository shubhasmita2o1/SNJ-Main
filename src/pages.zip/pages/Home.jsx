import React from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight, Sparkles, Quote } from "lucide-react";
import BackgroundVideo from "../components/BackgroundVideo";
import Container from "../components/Container";
import Reveal from "../components/Reveal";
import SEOHead from "../components/SEOHead";
import { useTranslation } from "react-i18next";
import SunLightVideo from "../assets/videos/SunLight.mp4";

const HERO_VIDEO = SunLightVideo;

const LOTUS_IMG =
  "https://images.unsplash.com/photo-1547100037-3308164630f2?crop=entropy&cs=srgb&fm=jpg&q=85&w=1600";
const MIST_IMG =
  "https://images.unsplash.com/photo-1600340053706-32d1278206ef?crop=entropy&cs=srgb&fm=jpg&q=85&w=1600";

const SOCIAL_IMG_INSTAGRAM = "https://images.unsplash.com/photo-1545389336-cf090694435e?crop=entropy&cs=srgb&fm=jpg&q=85&w=800";
const SOCIAL_IMG_FB = "https://images.unsplash.com/photo-1547100037-3308164630f2?crop=entropy&cs=srgb&fm=jpg&q=85&w=800";
const SOCIAL_IMG_YT = "https://images.unsplash.com/photo-1518609878373-06d740f60d8b?crop=entropy&cs=srgb&fm=jpg&q=85&w=800";
const SOCIAL_IMG_LI = "https://images.unsplash.com/photo-1604881744109-bf9aa6a25fdf?crop=entropy&cs=srgb&fm=jpg&q=85&w=800";


const SocialIcon = ({ name }) => {
  const icons = {
    Instagram: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5" aria-hidden="true">
        <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
      </svg>
    ),
    Facebook: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5" aria-hidden="true">
        <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>
      </svg>
    ),
    YouTube: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5" aria-hidden="true">
        <path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46a2.78 2.78 0 0 0-1.95 1.96A29 29 0 0 0 1 12a29 29 0 0 0 .46 5.58A2.78 2.78 0 0 0 3.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 0 0 1.95-1.95A29 29 0 0 0 23 12a29 29 0 0 0-.46-5.58z"/><polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02"/>
      </svg>
    ),
    LinkedIn: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5" aria-hidden="true">
        <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect width="4" height="12" x="2" y="9"/><circle cx="4" cy="4" r="2"/>
      </svg>
    ),
  };
  return icons[name] || null;
};

const SOCIAL_CHANNELS = [
  { iconName: "Instagram", label: "Instagram", handle: "@swasthanavjeevan", img: SOCIAL_IMG_INSTAGRAM, href: "#" },
  { iconName: "Facebook", label: "Facebook", handle: "Swastha NavJeevan", img: SOCIAL_IMG_FB, href: "#" },
  { iconName: "YouTube", label: "YouTube", handle: "SNJ Retreats", img: SOCIAL_IMG_YT, href: "#" },
  { iconName: "LinkedIn", label: "LinkedIn", handle: "Swastha NavJeevan", img: SOCIAL_IMG_LI, href: "#" },
];

export default function Home() {
  const { t, i18n } = useTranslation();
  const lang = i18n.language;
  const FOUR_D = t("home.4dCards", { returnObjects: true });
  const TWO_H_2R_2L = t("home.wellbeingCards", { returnObjects: true });

  return (
    <div data-testid="page-home">
      <SEOHead canonical="/" />

      {/* HERO */}
      <section className="relative w-full min-h-[100svh] overflow-hidden" aria-label="Hero">
        <BackgroundVideo src={HERO_VIDEO} brightness={0.7} blurPx={2} />

        <Container className="relative z-10 pt-44 md:pt-52 pb-32">
          <Reveal>
            <div className="flex justify-center">
              <span className="inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.24em] text-black/70 bg-white/55 backdrop-blur-md border border-black/5 rounded-full px-4 py-1.5">
                <Sparkles className="w-3 h-3" aria-hidden="true" /> {t("hero.eyebrow")}
              </span>
            </div>
          </Reveal>

          <Reveal delay={1}>
            <h1
              className="mt-8 text-center font-serif text-black leading-[0.95] tracking-[-0.025em] text-[56px] sm:text-[88px] md:text-[120px] lg:text-[140px] max-w-[1280px] mx-auto"
              data-testid="hero-headline"
            >
              {t("hero.line1")} <i className="text-black/60">{t("hero.italic1")}</i>
              <br />
              {t("hero.line2")} <i className="text-black/60">{t("hero.italic2")}</i>
            </h1>
          </Reveal>

          {/* Bilingual sub-heading for Hindi, always show both EN + current if not EN */}
          {lang !== "en" && (
            <Reveal delay={1}>
              <p className="mt-4 text-center font-serif text-[22px] md:text-[30px] text-[#6F6F6F] leading-[1.1]">
                Healing Beyond <i>Medicine.</i> Living Beyond <i>Cancer.</i>
              </p>
            </Reveal>
          )}

          <Reveal delay={2}>
            <p className="mt-10 max-w-[720px] mx-auto text-center text-[16px] md:text-[18px] leading-[1.65] text-[#1a1a1a]/85">
              {t("hero.subtitle")}
            </p>
          </Reveal>

          <Reveal delay={3}>
            <div className="mt-12 flex flex-wrap items-center justify-center gap-4">
              <Link to="/get-involved" className="btn-pill" data-testid="hero-cta-begin-journey">
                {t("hero.cta1")} <ArrowUpRight className="w-4 h-4" strokeWidth={1.7} />
              </Link>
              <Link to="/programme" className="btn-pill btn-ghost" data-testid="hero-cta-explore-programme">
                {t("hero.cta2")}
              </Link>
            </div>
          </Reveal>

          <Reveal delay={4}>
            <div className="mt-16 text-center text-[12px] tracking-[0.2em] uppercase text-[#6F6F6F]">
              {t("hero.initiative")}
            </div>
          </Reveal>
        </Container>
      </section>

      {/* 4D Framework */}
      <section className="py-28 md:py-40" data-testid="section-4d-framework">
        <Container>
          <div className="grid grid-cols-1 md:grid-cols-12 gap-10">
            <div className="md:col-span-5">
              <Reveal>
                <div className="text-[12px] uppercase tracking-[0.22em] text-[#6F6F6F]">
                  {t("home.4dEyebrow")}
                </div>
              </Reveal>
              <Reveal delay={1}>
                <h2 className="mt-6 font-serif text-[44px] md:text-[68px] leading-[0.98] tracking-[-0.02em]">
                  {t("home.4dTitle")}
                  <br />
                  <i className="text-[#6F6F6F]">{t("home.4dTitleItalic")}</i>
                </h2>
              </Reveal>
              <Reveal delay={2}>
                <p className="mt-6 text-[#6F6F6F] max-w-md leading-relaxed">
                  {t("home.4dBody")}
                </p>
              </Reveal>
            </div>

            <div className="md:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-5">
              {FOUR_D.map((d, i) => (
                <Reveal key={d.k} delay={(i % 4) + 1} className="snj-card p-7">
                  <div className="text-[11px] tracking-[0.2em] text-[#6F6F6F]">{d.k}</div>
                  <div className="font-serif text-[34px] leading-tight mt-2">{d.title}</div>
                  <p className="mt-4 text-[14px] text-[#6F6F6F] leading-relaxed">{d.desc}</p>
                </Reveal>
              ))}
            </div>
          </div>
        </Container>
      </section>

      {/* 2H 2R 2L Wellbeing model */}
      <section className="py-20 md:py-28 bg-[#fafafa] border-y border-black/5" data-testid="section-wellbeing-model">
        <Container>
          <Reveal>
            <div className="text-center text-[12px] uppercase tracking-[0.22em] text-[#6F6F6F]">
              {t("home.wellbeingEyebrow")}
            </div>
          </Reveal>
          <Reveal delay={1}>
            <h2 className="mt-6 text-center font-serif text-[40px] md:text-[60px] leading-[1] tracking-[-0.02em]">
              {t("home.wellbeingTitle")} <i className="text-[#6F6F6F]">{t("home.wellbeingTitleItalic")}</i>
            </h2>
          </Reveal>

          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
            {TWO_H_2R_2L.map((d, i) => (
              <Reveal key={d.k} delay={i + 1} className="snj-card p-8 text-center">
                <div className="font-serif text-[56px] leading-none">{d.k}</div>
                <div className="mt-3 text-[18px]">{d.title}</div>
                <p className="mt-3 text-[14px] text-[#6F6F6F] leading-relaxed">{d.desc}</p>
              </Reveal>
            ))}
          </div>
        </Container>
      </section>

      {/* Editorial split: Lotus + statement */}
      <section className="py-28 md:py-40" data-testid="section-editorial">
        <Container>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <Reveal className="lg:col-span-6">
              <img
                src={LOTUS_IMG}
                alt="Lotus blossom at first light"
                className="w-full h-[560px] object-cover rounded-[24px]"
                loading="lazy"
              />
            </Reveal>
            <div className="lg:col-span-6">
              <Reveal>
                <div className="text-[12px] uppercase tracking-[0.22em] text-[#6F6F6F]">
                  {t("home.editorialEyebrow")}
                </div>
              </Reveal>
              <Reveal delay={1}>
                <h3 className="mt-6 font-serif text-[44px] md:text-[64px] leading-[1] tracking-[-0.02em]">
                  {t("home.editorialTitle")} <i className="text-[#6F6F6F]">{t("home.editorialTitleItalic")}</i> <br /> {t("home.editorialTitle2")}
                </h3>
              </Reveal>
              <Reveal delay={2}>
                <p className="mt-8 text-[#6F6F6F] max-w-[520px] leading-relaxed">
                  {t("home.editorialBody")}
                </p>
              </Reveal>
              <Reveal delay={3}>
                <Link to="/programme" className="btn-pill mt-10" data-testid="editorial-cta-programme">
                  {t("home.editorialCta")} <ArrowUpRight className="w-4 h-4" />
                </Link>
              </Reveal>
            </div>
          </div>
        </Container>
      </section>

      {/* Science marquee strip */}
      <section className="py-14 border-y border-black/5 overflow-hidden" data-testid="section-science-strip" aria-label="Partner frameworks">
        <div className="relative">
          <div className="flex gap-16 marquee whitespace-nowrap items-center text-[#6F6F6F] font-serif text-[28px] md:text-[40px]">
            {Array.from({ length: 2 }).map((_, i) => (
              <div key={i} className="flex gap-16 items-center pr-16" aria-hidden={i === 1}>
                <span>NCCN</span>
                <span className="text-black/20">·</span>
                <span><i>ASCO</i></span>
                <span className="text-black/20">·</span>
                <span>ESMO</span>
                <span className="text-black/20">·</span>
                <span><i>SIO</i></span>
                <span className="text-black/20">·</span>
                <span>FACT-G</span>
                <span className="text-black/20">·</span>
                <span><i>HADS</i></span>
                <span className="text-black/20">·</span>
                <span>FACIT</span>
                <span className="text-black/20">·</span>
                <span><i>PSQI</i></span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Quote */}
      <section className="py-28 md:py-40" data-testid="section-quote">
        <Container size="narrow">
          <Reveal>
            <Quote className="w-8 h-8 text-black/20" strokeWidth={1.2} aria-hidden="true" />
          </Reveal>
          <Reveal delay={1}>
            <p className="mt-8 font-serif text-[36px] md:text-[56px] leading-[1.05] tracking-[-0.015em]">
              {t("home.quoteText")}{" "}
              <i className="text-[#6F6F6F]">{t("home.quoteItalic")}</i>
            </p>
          </Reveal>
          <Reveal delay={2}>
            <div className="mt-8 text-[12px] uppercase tracking-[0.24em] text-[#6F6F6F]">
              {t("home.quoteAttr")}
            </div>
          </Reveal>
        </Container>
      </section>

      {/* Social Media Section */}
      <section className="py-20 md:py-28 bg-[#fafafa] border-y border-black/5" data-testid="section-social">
        <Container>
          <Reveal>
            <div className="text-[12px] uppercase tracking-[0.22em] text-[#6F6F6F]">{t("home.socialEyebrow")}</div>
          </Reveal>
          <Reveal delay={1}>
            <h2 className="mt-6 font-serif text-[40px] md:text-[60px] leading-[1] tracking-[-0.02em]">
              {t("home.socialTitle")} <i className="text-[#6F6F6F]">{t("home.socialTitleItalic")}</i>
            </h2>
          </Reveal>

          <div className="mt-14 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {SOCIAL_CHANNELS.map((s, i) => (
              <Reveal key={s.label} delay={i + 1}>
                <a
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="snj-card block relative overflow-hidden group"
                  aria-label={`Follow us on ${s.label}: ${s.handle}`}
                >
                  <div className="relative h-[220px] overflow-hidden">
                    <img
                      src={s.img}
                      alt=""
                      aria-hidden="true"
                      className="w-full h-full object-cover transition-transform duration-[1200ms] group-hover:scale-105"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                    <span className="absolute top-4 right-4 text-white">
                      <SocialIcon name={s.iconName} />
                    </span>
                  </div>
                  <div className="p-5">
                    <div className="text-[11px] uppercase tracking-[0.2em] text-[#6F6F6F]">{s.label}</div>
                    <div className="mt-1 font-serif text-[20px] leading-tight">{s.handle}</div>
                  </div>
                </a>
              </Reveal>
            ))}
          </div>
        </Container>
      </section>

      {/* CTA banner */}
      <section className="relative py-32 md:py-40 overflow-hidden" data-testid="section-cta-banner">
        <img
          src={MIST_IMG}
          alt="Soft mist through trees"
          className="absolute inset-0 w-full h-full object-cover"
          style={{ filter: "brightness(0.78) blur(1px)" }}
          aria-hidden="true"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-white/40 via-white/10 to-white" />
        <Container className="relative">
          <Reveal>
            <h2 className="text-center font-serif text-[44px] md:text-[80px] leading-[1] tracking-[-0.02em] text-black">
              {t("home.ctaTitle")} <i className="text-[#6F6F6F]">{t("home.ctaTitleItalic")}</i>
            </h2>
          </Reveal>
          <Reveal delay={1}>
            <p className="mt-8 text-center max-w-[600px] mx-auto text-[#1a1a1a]/80">
              {t("home.ctaBody")}
            </p>
          </Reveal>
          <Reveal delay={2}>
            <div className="mt-10 flex justify-center">
              <Link to="/get-involved" className="btn-pill" data-testid="banner-cta-begin-journey">
                {t("hero.cta1")} <ArrowUpRight className="w-4 h-4" />
              </Link>
            </div>
          </Reveal>
        </Container>
      </section>
    </div>
  );
}
