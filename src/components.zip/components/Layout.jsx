import { useEffect, useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import Navbar from "./Navbar";
import Footer from "./Footer";
import WhatsAppFloat from "./WhatsAppFloat";
import AnnouncementPopup from "./AnnouncementPopup";
import AnnouncementFloat from "./AnnouncementFloat";
import ScrollProgress from "./ScrollProgress";

export default function Layout() {
  const location = useLocation();
  const [announcementOpen, setAnnouncementOpen] = useState(false);

  useEffect(() => {
    window.scrollTo({
      top: 0,
      behavior: "auto",
    });
  }, [location.pathname]);

  useEffect(() => {
    const timer = setTimeout(() => setAnnouncementOpen(true), 2200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen bg-white" data-testid="site-layout">
      <ScrollProgress />
      <Navbar />
      <main className="pt-0">
        <Outlet />
      </main>
      <Footer />
      <WhatsAppFloat />
      <AnnouncementFloat onClick={() => setAnnouncementOpen(true)} />
      <AnnouncementPopup open={announcementOpen} onClose={() => setAnnouncementOpen(false)} />
    </div>
  );
}