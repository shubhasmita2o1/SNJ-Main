import React, { useEffect, useRef, useState } from "react";

export const BackgroundVideo = ({
  src,
  poster,
  fadeMs = 600,
  className = "absolute inset-0 overflow-hidden",
  brightness = 0.78,
  blurPx = 1.5,
}) => {
  const videoRef = useRef(null);
  const [opacity, setOpacity] = useState(0);
  const [translateY, setTranslateY] = useState(0);

  // Fade in once when the video starts playing, then stay at full opacity
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;

    const onPlay = () => {
      setOpacity(1);
    };

    v.addEventListener("playing", onPlay);

    // Fallback: if already playing (e.g. cached)
    if (!v.paused) setOpacity(1);

    v.play().catch(() => {});

    return () => v.removeEventListener("playing", onPlay);
  }, [src]);

  // Parallax on scroll
  useEffect(() => {
    const onScroll = () => {
      setTranslateY(Math.min(window.scrollY * 0.25, 240));
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div
      className={`absolute inset-0 overflow-hidden ${className}`}
      data-testid="hero-background-video-wrapper"
      aria-hidden="true"
    >
      <video
        ref={videoRef}
        muted
        loop
        playsInline
        autoPlay
        preload="auto"
        poster={poster}
        className="absolute inset-0 w-full h-full object-cover"
        style={{
          opacity,
          transform: `translate3d(0, ${translateY}px, 0) scale(1.04)`,
          filter: `blur(${blurPx}px) brightness(${brightness})`,
          transition: `opacity ${fadeMs}ms ease, transform 80ms linear`,
        }}
      >
        <source src={src} type="video/mp4" />
      </video>

      <div className="absolute inset-0 hero-overlay pointer-events-none" />
      <div className="absolute inset-0 hero-vignette pointer-events-none" />
    </div>
  );
};

export default BackgroundVideo;
